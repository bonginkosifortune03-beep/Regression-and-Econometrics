# STK310 Regression and Econometrics Practicals (2025)

Eight practicals in **SAS** for **STK310** at the University of Pretoria, working through the
classical linear regression model and what to do when its assumptions break down.
Most of the work uses `PROC REG`, with `PROC IML` for matrix calculations, `PROC AUTOREG`
for autocorrelated errors, and `PROC UNIVARIATE`, `PROC CORR` and `PROC SGPLOT` for diagnostics.

## Contents

| Practical | Topic | What is done |
|---|---|---|
| [1](Prac-1_SAS-Basics-and-Simple-Regression) | SAS basics and simple regression | Importing data, descriptive statistics, correlation, a simple linear regression of Economics marks on Statistics marks, and the same estimates by matrix algebra in `PROC IML` |
| [2](Prac-2_Multiple-Regression-and-Diagnostics) | Multiple regression and diagnostics | Modelling music video file size from length and quality; residual analysis, normality (Shapiro-Wilk), t-tests and F-tests on coefficients |
| [3](Prac-3_Nonlinear-Models-and-Transformations) | Nonlinear models and transformations | Fitting a growth model to mouse mass by log transformation; log-linear and other functional forms (cereal data) |
| [4](Prac-4_Dummy-Variables-and-Chow-Test) | Dummy variables and structural change | Stadium cost for the 2014 FIFA World Cup with a construction-type dummy and interaction; the Chow test for a structural break |
| [5](Prac-5_Multicollinearity) | Multicollinearity | Consumption and car-price models; correlation matrices, VIF and collinearity diagnostics |
| [6](Prac-6_Heteroscedasticity) | Heteroscedasticity | House prices against size; detecting non-constant variance (including White's test) and correcting it with transformations and weighting |
| [7](Prac-7_Autocorrelation) | Autocorrelation | US copper prices 1951 to 1980 in log form; the Durbin-Watson test and the Cochrane-Orcutt procedure |
| [8](Prac-8_Distributed-Lag-Models) | Distributed lag models | Demand for money in Canada (quarterly, 1979 to 1988) and an expenditure model; lagged variables, Almon polynomial lags and `PROC AUTOREG` |

## How to run
Open a `.sas` file in SAS or SAS OnDemand for Academics. Each script imports its CSV with
`datafile="<name>.csv"`, so put the CSV in your SAS working folder or edit that path, then run it.

Practical 3 also imports `motorcycles.csv`, a lecture class-code file that is not included here.

## Author
Tlou (Maima) Bonginkosi Fortune
