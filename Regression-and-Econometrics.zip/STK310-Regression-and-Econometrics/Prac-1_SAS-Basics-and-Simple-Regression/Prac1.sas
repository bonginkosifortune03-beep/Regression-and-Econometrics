proc import datafile="MARKS.csv"
out=Marks
dbms=csv
replace;
run;


*Question 1;
proc univariate;
var Z;
run;

*Question 2;
proc corr cov;
var Z Y;
run;

proc iml;
Nu2a=12.80558**2;               print 'Number 2a' Nu2a;
Nu2b=11.15592**2;               print 'Number 2b' Nu2b;
Nu2c=121.4469697;               print 'Number 2c (Covariance)' Nu2c;

*Question 3;
proc iml;
use Marks; read all var {Z Y};
M=Z||Y;
print 'Question A:First Five observation' (M[1:5,]);


bii=sum(Z);             print 'Sum of Z' bii; 
b_ii=Z[+,];             print b_ii;        

biii=sum(Z##2);         print 'Uncorrected sum of squares Z' biii;
b_iii=(Z##2)[+,];       print b_iii;
 

biv=sum(Z[10:20]);              print 'Sum from 10 to 20' biv;
b_iii=(Z[10:20])[+,];           print b_iii;

bv=mean(Z);                     print 'Sample mean' bv; *This will give us a list of numbers";

bvi=sum((Z-bv)##2);             print 'The corrected sum of sqaures' bvi;

bvii=var(z);                    print 'sample variance' bvii;

bviii=sqrt(bvii);               print 'sample standard deviation' bviii;

ix=sum(Y);                      print 'sum of Y' ix;
ix_1=Y[+];                      print ix_1;

x=sum(Y##2);                    print 'sum of sqaure of Y' x;
x_1=(Y##2)[+,];                 print x_1;


xi=sum(Y[20:30]);              print 'sum of 20 to 30' xi;
xi_1=(Y[20:30])[+,];           print xi_1;

xii=mean(Y);                   print 'Sample mean of Y' xii;
 
xiii=sum((Y-xii)##2);                 print 'Corrected sum of squares for Y' xiii;

xiv=var(Y);                           print 'Sample variance of Y' xiv;

xv=sqrt(xiv);                         print 'sample standard deviation' xv;

xvi=sum(Z#Y);                         print 'Sum of product of Z and Y' xvi;
xvi_1=(Z#Y)[+,];                      print xvi_1;

xvii=sum((Z-bv)#(Y-xii))/(nrow(Y)-1);   print 'Covariance' xvii;
xviii=xvii/(xv*bviii);                  print 'The correlation coeffint' xviii;
 

*Number C;
c1=mean(M);          PRINT "mean of M" c1;
c2=var(M);            PRINT "variance of M" c2;
c3=std(M);           PRINT "standard deviation of M" c3;
c4=cov(M);           PRINT "The covariance of M" c4; 
c5=corr(M);          PRINT "Correlation of M" c5;

*Number D;
Ybar=mean(Y);
X=J(nrow(Z),1,1)||Z;                 print "This is matrix X " X;
B=inv(X`*X)*X`*y;                    print B;
SSE=(B`*X`*Y)-(nrow(Y)*Ybar**2);         print SSE;
SSR=Y`*Y-B`*X`*Y;                    print SSR;
SST=Y`*Y-nrow(Y)*Ybar##2;            print SST;
yhat=X*B;                            print yhat;
u=Y-yhat;                            print u;
sigma2=(u`*u)/(nrow(Y)-2);           print sigma2;
det=det(X`*X);                       print det; *This is a non-singular determinate;
CovB=sigma2*inv(X`*X);               print CovB;
R2=SSE/SST;                          print R2;
F=(SSE/1)/(SSR/(nrow(Y)-2));         print F;

*Number ii;
A=mean(Y);                          print "The mean vector of Y" A;
B=mean(yhat);                       print "The mean vector of yhat" B;
C=mean(u);                          print "The mean vector of u" C[f=10.4];

*Number 4;
*ask about this one;
data D1; set Marks;
Average=(Z+Y)/2;
if Average < 50          then AVECAT = 1;
if 50 <= Average < 75    then AVECAT = 2;
if Average => 75         then AVECAT= 3;
if Average => 50         then Pass = 1 ; else Pass=0;
run;*this is not working correctly;

*Number 5a;
proc means data=D1 maxdec=3;
WHERE Pass = 1;
var Average;
run;

*Number 5b;
proc means data=D1 maxdec=3;
WHERE AVECAT = 3;
var Average;
run;

*Number 6;

*Number 6a;
title "Scatter Plot for Statistic vs Economics";
PROC SGPLOT data=Marks;
xaxis label='Statistic mark(%)';
yaxis label='Economics mark(%)';
scatter x=Z y=Y;
run;

*Number 6b;
title "Scatter Plot for Statistic vs Economics";
PROC SGPLOT data=D1;
xaxis label='Statistic mark(%)';
yaxis label='Economics mark(%)';
scatter x=Z y=Y; 
scatter x=Z y=AVERAGE; *this is not working properly ;
run;

*Number 6C;
title "Scatter Plot for Statistic vs Economics";
PROC SGPLOT data=D1;
xaxis label='Statistic mark(%)';
yaxis label='Economics mark(%)';
scatter x=Z y=Y / group=AVECAT;
run; *It has only two groups fix that.;

*Doind the proc reg from the notes;
proc reg data=Marks;
model y = z/ p r;
id z;
run;


*Thank you GOD*
