proc import datafile="Expenditure.csv"
out=Expenditure
dbms=csv
replace;
run;

*Question 1a_i;
*so the model that we need to model is 
Yt=alpha(1-lambda)+B0*lambdat+Y(t-1)*lambdat+Vt;

*Step1;
*we then need to lag our y once;
data new; set Expenditure;
LagY=lag(Y);
LagX=lag5(X);
run;

*Step2:
*Then run an autoregression procedure;
proc autoreg data=new plots=none;
model Y=X LagY/lagdep=LagY; *this is the model specification;
run;
*Why not this one??;
/*
proc autoreg data=new plots=none;
model LagY=LagX LagY/lagdep=LagY;
run;
*/

*Alpha=0.2717
 Interpreation: This means that the rate at which the beta coefficients decrease
                which measures the impact of past explanatory variables further 
                removed from the current value of the dependent variable in a 
                geometric way.

                If the rate of decline is closer to 1, the betas decrease slower
                and if the rate of decline is closer to zero, the betas decrease faster
                lambda=0.2717, therefore the betas decrease faster;



*Question 1a_ii;
*Speed of adjustment;
proc iml;
Alpha=0.2717;
SOA=1-Alpha; print "Speed of adjustment" SOA;
*1-alpha=0.7283;
quit;
*Interpretation: This measure the speed with which the dependent variable
                 adjust to the impact of past explanatory variable

If 1-alpha=1 then this means the speed of adjustment to past explanatory variable is high
If 1-alpha=0 then this means the speed of adjustment ot past explanatory variable is low
If alpha=1 this means that 1-alpha=0
If alpha=0 this means that 1-alpha=1
1-alpha=0.7283 means that the speed of adjument is high;

*Question 1a_iii;
proc iml;
medianlag=-log(2)/log(0.2717);  print 'Median lag' medianlag;
*MeanLag=0.5319394;

*then if we want to interprete it in months;
medianlag_Months=mmedianlag*12; print 'Median lag in months' medianlag_Months;
*which is 6.3832723

Interpretion: 50% of the total changw in business expenditure for new plants
              and equipment (in billions of dollar) takes effect in the just 
              more that half a year (meaninf plus of minus 6 months);

*Continue withg the mean lag;
meanLag=(0.2717)/(1-0.2717);    print 'Mean lag' meanLag;
*the mean lag is 0.3730606;
meanLag_Months=meanLag*12;      print 'Mean lag in months' meanLag_Months;
*Interpretation: 4.4767 means that mean lag is between 4 and 5 months, showing on the 
                 average for the effects of changes in sales(in billion dollors) to be 
                 felt on business expenditure for new plants and equipment(in billions of dollar) change;
quit;


*Question 1a_iv;
proc iml;
*need to estimate beta values;
Beta_Zero=0.6293;
lambda=0.2717;
*then us the do loop to get all 4 betas;
betaK=J(5,1,.);
do i=0 to 4;
betaK[i+1]=Beta_Zero*lambda##i;
end;
print betaK;


*Question 1a_v;
*Getting the short-run distributed lag multiplier;
*Beta0=0.6293


*Question 1a_vi;
*Estimated long run distributed lag multiplier;
LR=sum(betaK); print 'long run distributed lag multiplier' LR;


*Question 1a_vii;
*Estimated regression model
Yhat=-15.1040+0.6293*Xt+0.1709808*Xt-1+0.0464555*Xt-2+0.012622*Xt-3+0.0034294*Xt-4;

*Question 1a_viii;
*using the h statistics

Ho: No positive or negativbe first order autocorrelation vs
H1: Positive or negative first order autocorrelation


hstat=1.2280 
pvalue=0.1097;
Crit=quantile('normal',1-(0.05/2),0,1); print  Crit;

*Decision: It means we do not reject the null hypothesis at 5% level of significance

Conclusion: Thus we do not have enough statistical evidence to suggest that the is 
           a presence of negative or positive autocorrelation in the estimeatec error terms;
quit;


*then now the Almond Approach;
data new2; set Expenditure;
z0=X+lag(X)+lag2(X)+lag3(X)+lag4(X);
z1=lag(X)+2*lag2(X)+3*lag3(X)+4*lag4(X);
z2=lag(X)+4*lag2(X)+9*lag3(X)+16*lag4(X);
z3=lag(X)+8*lag2(X)+27*lag3(X)+64*lag4(X);
run;

*then we need to run proc reg for the z's;
proc reg data=new2 plots=none;
model Y=z0 z1 z2 z3/covb;
run;


*Question 1b_ii;
*then you need to determine betas;
proc iml;
a0hat=0.66271;
a1hat=0.60702;
a2hat=-0.77350;
a3hat=0.14705;
*then create placeholder;
betaAlmond=J(5,1,.);
do i=0 to 4;
betaAlmond[i+1]=a0hat+ i*a1hat+ i**2*a2hat+ i**3*a3hat;
end;
print betaAlmond;


*Question 1b_iii;
*then we need to get the variance;

cov={0.0428656448 -0.124752766 0.0698651822 -0.010610412,
 -0.124752766 0.5713866145 -0.367594374 0.0593440824,
 0.0698651822 -0.367594374 0.246934602 -0.040799606,
 -0.010610412 0.0593440824 -0.040799606 0.0068341573};
*print cov;

*then we need to create do to get all the variance of betas;
 varbeta=J(5,1,.);
 do i=0 to 4;
 const=1||i||i**2||i**3;
 varbeta[i+1]=const*cov*const`;
 end;
 print 'Variance of beta' varbeta;


*getting the standard deviation;
 stdbeta=sqrt(varbeta); print stdbeta;
 *getting the t statistic;
 t=betaAlmond/stdbeta;
 print t;

 *then we need to pv and the critical value;
pv=J(5,1,.);
Crti=J(5,1,.);
 do i=0 to 5;
 pv[i+1]=2*(1-cdf('t',abs(t[i+1]),13));
 Crti[i+1]=quantile("t",0.975,13);
 end;
 print 'Pvalue' pv;
 print 'Critical value' Crti;
quit; 




