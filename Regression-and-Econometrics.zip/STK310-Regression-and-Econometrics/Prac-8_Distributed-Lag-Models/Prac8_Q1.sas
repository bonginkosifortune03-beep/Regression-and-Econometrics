proc import datafile="Money.csv"
out=Money
dbms=csv
replace;
run;

*Question 1a;
*then we need to do double log transformation;

*Question 1b;
data new; set Money;
LnM=log(M);
LnR=log(R);
LnY=log(Y);
run;

*Question 1b_ii;
*then we need to estimate the regression model;
proc reg data=new plots=none;
model LnM=LnR LnY;
run;

*LnMt_hat=-8.75009-0.06660*LnRt+1.49270*LnYt;

*Question 1b_iii;
*then the interpretation of B2:
  It means every 1% increase in aggregate real national in millions
  will cause an increase in the expected long run demand  for money by 1.49270% if all the other
  varaibles are kept constant;

*Question 1b_iv;
*we need to calculate the mean prediction intverval;
proc reg data=new plots=none;
model LnM=LnR LnY/alpha=0.01 clm;
id Year quarter;
run;
proc iml;
L=exp(10.0970)*1000000;
U=exp(10.1460)*1000000;
print L[f=20.2] U[F=20.2];
quit;
*the Prediction interval is ( 24270089830.22, 25488942253.98);

*Question 1b_iv;
proc reg data=new plots=none;
model LnM=LnR LnY/dw;
run;
proc iml;
D=0.348;
N=40;
K=2;
Dl=1.391;
Du=1.600;
*we can see that 0 <0.348< 1.391
Decision: We reject the null hypothesis of no positive autocorrelation
          at the 5% level of significance
Conclusion: We thus have enough statistcal evidence to suggest that they is presence
           of positive correlation;

*Question 1c;
*Cochrane-Orcutt;
proc reg data=new plots=none;
model LnM=LnR LnY/r;
output out=Residuals
r=res;
run;

*then we need to lag the residuals;
data new1; set Residuals;
lagRes=lag(res);
run;
*then do regression model with no intercept;
proc reg data=new1 plots=none;
model res=lagRes/noint;
run;
*then we need to do tranfromation;
*0.77260;
data new2; set new1;
L_LnM=lag(LnM);
L_LnR=lag(LnR);
L_LnY=lag(LnY);

Lt_LnM=LnM-0.7726*L_LnM;
Lt_LnR=LnR-0.7726*L_LnR;
Lt_LnY=LnY-0.7726*L_LnY;
run;

proc reg data=new2 plots=none;
model Lt_LnM=Lt_LnR Lt_LnY/dw;
run;
*our Dstat=1.782
Mhat=-1.67819-0.04943*R*+1.38383*Y*
;

