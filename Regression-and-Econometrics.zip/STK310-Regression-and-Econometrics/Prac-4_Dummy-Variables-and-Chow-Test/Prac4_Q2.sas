proc import datafile="Chow test data (3).csv"
out=Savings
dbms=csv
replace;
run;

**Yt=Savings (in dollar)
  Xt=Disposable income (in dolllars);

*Question 2a;
*
If Xt>$2500 then D1=1
If Xt<=$2500 then D1=0;
*

*Question 2b;
*
bi= r1 + alpha1*Xt + ui
bii=(r1 - alpha2*X*) + (alpha1+alpha2)Xt + ui; *ask about this;
*;
data newdummy; set Savings;
X=2500;
if Income>2500 then D1=1; else D1=0;
Dx=(Income-X)*D1;
run;

proc reg data=newdummy plots=none;
model Savings= Income Dx;
run;
*Before the threshold:
   yhat=7.65412+0.07469*Xt

After the threshold:
   yhat=161.85412+0.01301*Xt
;

proc iml;
*this is for after the threshold;
b1=7.65412-(-0.06168*2500); print b1;
b2=0.07469+(-0.06168); print b2;
quit;


*Question 2c;
proc reg data=newdummy plots=none;
model Savings= Income Dx;
run;
*For Disposal income:

Ho:alpha2=0
H1:alpha2 not equal to zero

The pvalue=0.0001 which is less than 0.05 then we do reject the null hypothesis at 5% level of significance

Conclusion:There is statistical evidence to suggest that structural break for disposable income is not equal 
          to zero 
          Which suggest that there was a signficant strutural break in thr regression at the threhold of $2500
          which affects the intercept and the slope of the regression line;

*Question 2d;
proc iml;
*Getting the estimated expected savings amount in 1968 if disposable income
 is $600 (IN 1968 is before threhold;

X=600;
yhat=7.65412+0.07469*X;  print 'Expected savings' yhat;
quit;

*Question 2e;
proc reg data=newdummy plots=none;
model Savings= Income Dx / p r cli clm alpha=0.01;
id Year;
run;
*the prediction interval is (148.5624, 283.5374) 


*Do Question 3;





