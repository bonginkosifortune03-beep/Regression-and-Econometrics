proc import datafile="FIFA.csv"
out=Fifa
dbms=csv
replace;
run;

*Yi=Construction cost
 Xi=The capacity of the stadium
 Di=1 when construction type is R and 0 elsewhere;


*Question 1;

*we need dummy dataset;
data dummy;set Fifa;
if Construction_type="R" then D1=1; else D1=0;
D2=D1*Capacity;  *also creating an interaction variable;
run;

proc reg data=dummy plots=none;
model Construction_cost= Capacity D1 D2;
run;

**i--E[Yi|Di=1,Xi]=(r1+r2) + X1(a1+a2) + Ui;
**i_i--E[Yi|Di=0,Xi]=r1+ X1a1 + Ui;

*Question 1iii;

**ii= -240.3692+ 0.00696Xi   *This is the estimated regression function for renovated stadiums;
**ii_II=-38.58355+0.00566Xi  *This is the estimated regression function for new stadium;

proc iml;
ri=(-38.58355-201.78560); print 'R one' ri;
a1_a2=0.00566+0.00130; print a1_a2;
quit;


*Question 1_iv;
*for testing the signifince we need to look at the pvalue of each coefficient;
proc reg data=dummy plots=none;
model Construction_cost= Capacity D1 D2;
run;
**For r2

Ho:r2=0
H1:r2 not equal to 0

pvalue=0.3332 which is greater than 0.05 thus we  do not reject the null hypothesis at 5% level of significance

Conclusion:We do not have enough statistical evidence to suggest that differential intercept coefficient differs from zero
           thus this means these two intercepts do not differ significanly (due to the large standard errors of intercepts)
           Even thoug the two values in the sample seem to differ, the precision accuracy is so low due to the large standard errors
           there is no statistical difference between the two values autonomous construction cost values

For alpha2

Ho:alpha2=0
H1:alpha2 not equal to 0

pvalue=0.7173 which is greater than 0.05 thus we do not reject the null hypothesis at 5% level of significance

Conclusion:There is no enough statistical evidence to suggest that the differential slope coefficint differs from zero
           therefore the two slope do not differ significantly.
           Meaning that a unit change in capacity (one additional set) on a unit change in construction cost (a 1 million pound increase)
           of renovated or new stadium does not differ significantly;

*Question 1_vi;
data graphs;set dummy;
x=Capacity;
yhat_R=-240.3692+ 0.00696*x;
yhat_NR=-38.58355+0.00566*x;
run;

proc sgplot data=graphs;
title 'Construsction cost vs Capacity and renovation type';
xaxis label='Capacity';
yaxis label='Costruction cost';
scatter x=Capacity y=Construction_cost/ group=Construction_type;
reg x=x y=yhat_R/ markerattrs=(color=green)curvelabel='yhat_R=-240.3692+ 0.00696*x' curvelabelloc=outside;
reg x=x y=yhat_NR/ markerattrs=(color=blue)curvelabel='-38.58355+0.00566*x' curvelabelloc=outside;
run;


*Question 1b;
proc iml;
*we need to substitute Capacity of 500000 on the new renovated stadium equation;
x=50000;
yhat=-38.58355+0.00566*50000; print 'Construction cost' yhat;
quit;


