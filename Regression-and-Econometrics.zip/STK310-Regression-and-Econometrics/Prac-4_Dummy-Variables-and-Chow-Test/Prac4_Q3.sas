proc iml;
n=50; r=500;
dim=n||r;
*The generated data;
call randseed(240,1); X=randfun(dim,'normal',20,4);
call randseed(189,1); U=randfun(dim,'normal',0,2);
call randseed(222,1); E=randfun(dim,'normal',1,3);

*for the sample data;
dim1=r||n;
prob=0.4||0.6;
call randseed(540,1); D=sample({0,1},dim1,"Replace",prob);

*Creating the interation term;
DX=D#X+E;
*print DX;

*Then we need to create y values;
Y=J(n,r,.);    *which is the placeholder for yvlaues;
do i=1 to r;
Y[,i]=5*J(n,1,1)+3*D[,i]+8.5*X[,i]+2.75*DX[,i]+U[,i];  *the y sample data;

*then we need to create a design matric that has all the parameter we wanna estimate;



*then we need to betas;
beta=inv(XX`*XX)*XX`*Y[,i];
*then get the yhat;
yhat=XX*beta;
*then we can get the residuals;
res=Y[,i]-yhat; 

*then we need to populate the betas and residuals for all sample;
beta_all=beta_all||beta;
res_all=res_all||res;

*then getting the means and standard deviations for betas estimated;
mean_Beta=mean(beta_all`)`; 
std_Beta=std(beta_all`)`;
*print mean_Beta std_Beta;

*we can also get the means and standard deviations of residuals;
*mean_Res=mean(res_all`)`;
*std_Res=std(res_all`)`;
end;
print mean_Beta std_Beta; *for beta;
*print mean_Res std_Res;

*Looking at the data we can see that as N increase out prameter estimates move closer to the true values estimated
 and our standard deviation decrease more meaning that the is less variation between our parameters;

*From the lecture memo:
In general the parameter estimates seem unbiased compared to the true parameter values specified in the 
original model, but the most significant trend is seen that when n and r increase the precision with which
the parameter are estimated become more higher, since the standard error becomes smaller;

