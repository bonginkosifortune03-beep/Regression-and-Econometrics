proc import datafile="prices.csv"
out=prices
dbms=csv
replace;
run;

*Question 1a;
proc sgplot data=prices;
xaxis label="House Size(in sqaure meter)";
yaxis label="House price(in R100000)";
scatter y=Y x=X;
reg y=y x=x;
run;
*we can see that as our explanatory variable increase our variation
increase the is not variance;

*Question 1bi;
*we then need to fit the Ordinart least square;
proc reg data=prices plots=none;
model Y=X;
output out=residuals
p=Pred
r=res;
run;

*Yhat=-20.04031+2.06731*X1;


*Question 1bii;
*Interpretation of B2:
 When the size of the house increase by 1 sqaure meter, the expected price of the
 house will increase by R20673.10;

*Question 1biii;
proc univariate data=residuals normal;
var res;
run;

*Ho:The residuals' distribution does not differ from a normal distribution VS
 H1:The residuals' distribution does differ from the normal distribution

P-value=0.0703 which is greater than 0.05 this means we do not reject the null hypothesis

Conclusion:This means we not have enough statistical evidences to suggest that the residuals'
           distribution differs from the normal distribution;

*Question 1biv;
data new; set residuals;
sRes=res**2;
run;

proc sgplot data=new;
 scatter y=sRes x=X;
 run;
 *The is a clear graphical indication that there are unequal error variation
 which increase as the house size increase;


*Question 1bv_A;
*This goes with steps so we need to sort our data in terms of X values;
 proc sort data=new;
 by X;
 run;

 *we then need to determine the number of observstion in the two dataset that we will
 create;
 proc iml;
 c=8;
 n=50;
 newN=(50-C)/2; print newN;
 quit;
 *We see that our first dataset will have 21 values;
 *then we need to do proc regressino on the first 20 observation;
 proc reg data=new (obs=21) plots=none;
 model y=x;
 run;
 *then our second dataset number of observation;
 proc iml;
 n=21+9; print n;
 quit;
 *then do our second dataset proc regression;
 proc reg data=new (firstobs=30) plots=none;
 model y=x;
 run;
 proc iml;
 Ftest=(37017/19)/(6664.25849/19);   print 'F test statistics' Ftest;
 Fcrit=quantile('f',(1-0.05),19,19); print 'F critical values' Fcrit;
 Fvalue=1-cdf('f',Ftest,19,19);      print 'Pvalue of F' Fvalue;
 quit;
*then we need to do our hypothesis testing;
 *Ho: Homoscedasticity(equal error variance) vs
  H1: Heteroscedasticity(uneqal error variances)

 Decesion: We reject the null hypothesis at 5% level of significance since Test Statistics is greater than the critical value
           Also the pvalue is less than the 5% level of significance
 Conclusion:We thus have enough statistical eveidence to suggest that error of variances are uneqaul 
            meaning we do know that the is heteroscedastic;


*Question 1bv_B;
 *we need new data for maximum likehood  estimator and variable pi;
 data new1; set new;
 sigma2=51108/48;  *(RSS)we get this from the normal proc regression;
 sigma2MLE=sigma2*(48/50);
 pi=sRes/sigma2MLE;
 run;
 *then we need to proc regression on the new data;
proc reg data=new1 plots=none;
model pi=x;
run; 
proc iml;
ESS=30.09479;  *From regressing pi on x;
ChisTest=(1/2)*ESS;                    print 'This is Chisq Test statistics' ChisTest;
ChisCrit=quantile('chisq',1-0.05,1);   print 'Critical value' ChisCrit;
ChisPvalue=1-cdf('chisq',ChisTest,1);  print 'Pvalue' ChisPvalue;
quit;
*then we need to do the hypothesis testing

Ho=Homoscedasticity(equal error variance)
H1=Heteroscedasticity(unequal error variance

Decision:We thus reject the null hypothesis since Pvalue is less than 5% level 
        of significance.
        Also our test statistics is greater than the critical value
Conclusion: There is enough statistical evidence to suggest that we have heteroscadesity
          meaning the error varainces are unequal;

*Question 1bv_C;
*we need to create new for XSQ where we are sqauring our x values;
data new2; set new1;
xsq=x**2;
run;

*then use regression to obtain R2 the adjusted one;
proc reg data=new2 plots=none;
model sRes=x xsq;
run;

proc iml;
adjR2=0.6579;
n=50;
ChqTest=50*adjR2; print 'Our Test statistic' ChqTest;
crti=quantile('chisq',(1-0.05),2); print 'Critical value' crti;
pvalue=1-cdf('chisq',ChqTest,2);   print 'This is probability value' pvalue;
quit;

*then we can do the hypothesis testing
Ho:Homoscedasticity(equal error variance) vs
H1:Heteroscedasticity(uneqaul error variance)

Decision: We reject the null hypothesis at 5% since pvalue is less than 0.05 and
         test statistics is greater than our critical value
Conclusion:We have enough statistical evidence to suggest that error of variances are unequal
          thus meaning the is heteroscadestity;

*Question b_vi_A;
*we neeed to do a new transformation by diving by X;
data new3; set new2;
Yt=y/x;
Xt=1/x; *for the intercept;
run;
*then we need to refit the model to get the new regression analysis;
proc reg data=new3 plots=none;
model Yt=Xt;
run;
*Our new Yhat=-15.9168+2.04454*Xi the slope and intercept interchange;


*Question b_vi_B;
proc iml;
x=450;
Y=-15.9168+2.04454*X; print 'Expected house price' Y;
Yhat=Y*10000; print 'Expected house price (in Rand)' Yhat;
quit;


*Question b_vii_A;
*for this one we need to divide by square root of X;
data new4; set new3;
yt2=y/sqrt(x);
xt21=1/sqrt(x);
xt22=sqrt(x);
run;
*then we need to fit a new regression;
proc reg data=new4 plots=none;
model yt2=xt21 xt22/noint;
run;

*Question b_vii_B;
*thus the new Yhat=-17.03929+2.05155*X;
proc iml;
X1=450;
Y1=-17.03929+2.05155*X1; print Y1;
yhat1=Y*10000;          print 'Expected house price(in Rand)' yhat1;
quit;


*Question b_viii_A;
*we need to do the log transformation;
data new5; set new4;
yt3=log(y);
xt3=log(x);
run;
*then do another prov regression;
proc reg data=new5 plots=none;
model yt3=xt3;
run;
*then our estimated log model
lnYhat=0.35809+1.05880lnXi;

*Question b_viii_B;
*Interpretation of B2: This means that the when size of the house increase by 1% the 
                       expected price of the house will increase by 1.06%

*Question b_viii_C;
proc reg data=new5 plots=none;
model yt3=xt3/cli alpha=0.01;
id Y X;
output out=ResC
r=resC;
run;
*then we need to do a proc univariate;
proc univariate data=ResC normal;
var resC;
run;
*Decision: Looking at the pvalue=<0.0050 which is less than 0.05 thus we reject 
           the null hypothesis
Conclusion: Thus we have enough statistical to suggest that the residuals' distibution
            differs from the normal distribution;

*Question b_viii_D;
*The tranformed prediction interval
 (5.8335,6.2555)
*then the transformed interval based on the units;
proc iml;
l=exp(5.8335)*10000; print l;
u=exp(6.2555)*10000; print u;
quit;
*The tranformed prediction interval
 (5.8335,6.2555)
thus the normal interval= (3415520.2,5208697.4;


*Question b_viii_E;
*for this one we need to calculate the prediction interval manually
since the 400m2 is not observed;

*we then need to get the mean and css using proc univariate on the transformed data;
proc univariate data=new5;
var xt3 ;
run;
proc iml;
lnX=log(400);
lnYhat0=0.35809+1.05880*lnX; print lnYhat0[F=10.4];


sigma2_Or=0.00604; *from the transformed data;
n=50;
mean_xt3=5.17053389; *from the transformed data;
css=8.73512564;      *from the transformed data;

*then calculate the new sigma2;
sigma2=(sigma2_Or)*(1+(1/n)+((lnX-mean_xt3)**2)/(css)); print sigma2;
sigma=sqrt(sigma2); print sigma;

*then we need to calculate the margin of error;
*L_Margin=quantile('t',(0.01/2),2) print L_Margin;
Margin=quantile('t',1-(0.01/2),(n-2));  print Margin;

*calculating the lower and upper bound;
L_Bound=lnYhat0-Margin*sqrt(sigma2); print L_Bound;
U_Bound=lnYhat0+Margin*sqrt(sigma2); print U_Bound;

*Then we need to get the original interval in correct units;
Ori_L_Bound=exp(L_Bound)*10000; print Ori_L_Bound;
Ori_U_Bound=exp(U_Bound)*10000; print Ori_U_Bound;
*Then correct interval is (R6542617.5,R10125682);
quit;

*Question b_ix;
*Question 1bi;
*we then need to fit the Ordinart least square;
*Then when you want to calculate the White's Heteroscedasticity corrected standard error
you just need to put in WHITE;
proc reg data=prices plots=none;
model Y=X/ white;
output out=residuals
p=Pred
r=res;
run;

*Looking at the original OLS standard error=0.06567 while the White 
 Heteroscedasticity corrected standard error=0.07424

 Meaning that it was underestimated since it is less than that of 
 Heteroscedasticity corrected standard error;


