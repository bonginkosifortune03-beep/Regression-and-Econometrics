proc import datafile="music.csv"
out=music
dbms=csv
replace;
run;



*Question 1a;
proc sgplot data=music;
scatter x=Length y=Size;
run;

/*look your data before you fit any regression line*/

*Question 1b;
proc sgplot data=music;
scatter x=Length y=Size / group=Quality;
run;

*Question 1c;
" The data has an outlier
";


*Question 2a;
proc corr data=music cov;
var size length;
run;
"Interpretation:The is a moderate positive linear relationship between Size(in MB) and Length(in second) of 0.70427";

*Question 2b;
proc reg data=music ;
model size=length/ p r covb;
id=length;
run;
"
Regression line: Y=-5.58638+0.09607*Xi
B1= the expected file size(in MB) will be -5.58638 MB for a song length of 0 seconds;
B2=The expected file size will increase by 0.09607 MB for every additional second of a song length 

*Look at the Cooked D statistics looks at the residual
Remove for example obeservstion 18 as a problematic value
";


*Question 2c;
proc reg data=music ;
model size=length/ p r covb;
id=length;
run;
"
The estimate for Error Mean Square=89.99992;
";

*Question 2d;
proc reg data=music ;
model size=length/ p r covb;
id=length;
run;
"Var(B1)=5.50112**2=30.262321
Var(B2)=0.01977**2=0.0003909
";

*Question 2e;
proc reg data=music ;
model size=length/ p r covb;
id=length;
run;
"
Cov(B1,B2)=-0.102338273;
";

*Question 2f;
proc reg data=music ;
model size=length/ p r covb;
id=length;
run;
"
The coeffiencet of determination is 0.4960 
Interpertation:49.6% of the total variation in file size(in MB) IS expalained by thr variation in the song length (in seconds)
";

*Question 2g;
proc reg data=music ;
model size=length/ p r covb;
output out=residuals
      p=PreSize
	  r=res;
run;

proc univariate data=residuals plot normal;
var res;
histogram/normal;
run;
"
using 0.01 level of significance

i.Shapiro-Wilks test 
ii.Kolmogorov-Smirnov test::: The pvalue=0.010 which is equal to 0.01 level of significance thus we do not reject Null hypothesis
iii.Cramer-von Mises test:::: The pvalue=0.005 which is less than 0.01 level of significance thus we reject Null hypothesis
iv.Anderson-Darling test::::: The pvalue=0.005 which is less than 0.01 level of significance thus we reject Null hypothesis

Conclusion::There is enough statistical evidence to suggest that the distribution of the
residuals di�ers from the normal distribution
";

*Question 3a;
proc iml;
use music; read all var{size length} into M;
print M;
y=M[,1];   *The size of the songs;
x=M[,2];   *The length of the songs;

Q3ai=nrow(x);                   print "Number of observtion of X" Q3ai;
Q3aii=sum(x);                   print "Sum of X" Q3aii;
Q3aiii=sum(x##2);               print "Uncorrected sum of squares of X*" Q3aiii;
Q3aiv=mean(x);                  print "Mean of X" Q3aiv;
Q3av=sum((x-mean(x))##2);       print "Corrected sum of squares" Q3av;
Q3avi=sum(y);                   print "Sum of Y" Q3avi;
Q3avii=mean(y);                 print "Mean of Y" Q3avii;
Q3aviii=sum(x#y);               print "Sum of product of X and Y" Q3aviii;
Q3aix=sum((y-mean(y))##2);      print "Corrected sum of squares" Q3aix;

*Question 3b;
Q3bi=(Q3ai*Q3aviii-Q3aii*Q3avi)/(Q3ai*Q3aiii-(Q3aii**2)); print "The slope parameter B2" Q3bi;
Q3bii=Q3avii-Q3bi*Q3aiv;                                  print "The intercept parameter B1" Q3bii;
yhat=Q3bii+Q3bi#X;                                        print "Estimated Y" yhat; 
Q3biii=sum((y-yhat)##2);                                  print "Sum of residuals" Q3biii;
Q3iv=Q3biii/(nrow(Y)-2);                                  print "Mean square error" Q3iv;
Q3v=sqrt(Q3iv)/(sqrt(Q3av));                              print "standard error for B2" Q3v;
Q3vi=sqrt(Q3iv)*sqrt((Q3aiii/(Q3ai*Q3av)));                 print "standard error for B1" Q3vi;
Q3vii=Q3bi*Q3av;  *This is wrong;                                        print Q3vii;
Q3viii=1-Q3biii/sum((y-mean(y))##2);                      print "Coeffient of determination" Q3viii;
xbar=sum(x)/Q3ai; print xbar;
Q3ix=-(xbar*Q3v**2);                                         print "Covariance of B1 and B2" Q3ix;

*Question 4;
/* Step 1: Run Regression and Calculate Cook's Distance 
proc reg data=music;
    model length = size / influence;
    output out=reg_out cookd=cooksD;
run;

/* Step 2: Remove High-Leverage Outliers 
data cleanMusic;
    set reg_out;
    if cooksD < 4 / _N_;  /* Remove points with high Cook's Distance 
run;

/* Step 3: Fit Regression Again on Cleaned Data *
proc reg data=cleanMusic;
    model length = size;
run;
*/


/*Using Mem's  way*/
data cleanMusic1; set music;
if artist="R" then delete;
run;




*Question 4_1a;
proc sgplot data=cleanMusic1;
scatter x=Size y=Length;
run;

*Question 4_1b;
proc sgplot data=cleanMusic1;
scatter x=Size y=Length / group=Quality;
run;

*Question 4_2a;
proc corr data=cleanMusic1 cov;
var size length;
run;
"Interpretation:The is a fairly strong positive linear relationship between Size and Length of 0.85266";


*Question 4_2b;
proc reg data=cleanMusic1 ;
model size=length/ p r covb;
id=length;
run;
"
Regression line: Y=-3.45738+0.08187*Xi
B1= -3.45738 gives the mean value of Y at a given X=0;
B2=A one unit increase will result in the expected value of Y to increase by 0.08187
";

*Question 4_2c;
proc reg data=cleanMusic1 ;
model size=length/ p r covb;
id=length;
run;
"
The estimate for MSE=4.94842;
";

*Question 4_2d;
proc reg data=cleanMusic1 ;
model size=length/ p r covb;
id=length;
run;
"Var(B1)=2.88153**2=8.3032151
Var(B2)=0.01046**2=0.0001094
";


*Question 4_2e;
proc reg data=cleanMusic1 ;
model size=length/ p r covb;
id=length;
run;
"
Cov(B1,B2)=-0.02830752;
";

*Question 4_2f;
proc reg data=cleanMusic1 ;
model size=length/ p r covb;
id=length;
run;
"
The coeffiencet of determination is 72.70% 
Interpertation:The total variancion of Size of a song is explained by the variation in the length of the songs
";

*Question 4_2g;
proc reg data=cleanMusic1 ;
model size=length/ p r covb;
output out=residualsclean
      p=PreSize
	  r=res;
run;

proc univariate data=residualsclean plot normal;
var res;
histogram/normal;
run;
"
using 0.05 level of significance

i.Shapiro-Wilks test::::::
ii.Kolmogorov-Smirnov test::: The pvalue=0.067 which is greater than 0.05 level of significance thus we  do not reject Null hypothesis
iii.Cramer-von Mises test:::: The pvalue=0.060 which is greater than 0.05 level of significance thus we  do not reject Null hypothesis
iv.Anderson-Darling test::::: The pvalue=0.062 which is greater than 0.05 level of significance thus we  do not reject Null hypothesis
";

*Question 4_3a;
proc iml;
use cleanMusic1; read all var {size length} into CM;
xx=CM[,2]; 
yy=CM[,1]; 

Q4_3ai=nrow(xx);                      print "Number of observtion of X" Q4_3ai;
Q4_3aii=sum(xx);                      print "Sum of X" Q4_3aii;
Q4_3aiii=sum(xx##2);                  print "Uncorrected sum of squares of X*" Q4_3aiii;
Q4_3aiv=mean(xx);                     print "Mean of X" Q4_3aiv;
Q4_3av=sum((xx-mean(xx))##2);         print "Corrected sum of squares" Q4_3av;
Q4_3avi=sum(yy);                      print "Sum of Y" Q4_3avi;
Q4_3avii=mean(yy);                    print "Mean of Y" Q4_3avii;
Q4_3aviii=sum(xx#yy);                 print "Sum of product of X and Y" Q4_3aviii;
Q4_3aix=sum((yy-mean(yy))##2);        print "Corrected sum of squares" Q4_3aix;

*Question 4_3b;
Q4_3bi=(Q4_3ai*Q4_3aviii-Q4_3aii*Q4_3avi)/(Q4_3ai*Q4_3aiii-(Q4_3aii**2)); print "The slope parameter B2" Q4_3bi;
Q4_3bii=Q4_3avii-Q4_3bi*Q4_3aiv;                                          print "The intercept parameter B1" Q4_3bii;
yhatt=Q4_3bii+Q4_3bi#xx;                                                   print "Estimated Y" yhatt; 
Q4_3biii=sum((yy-yhatt)##2);                                              print "Sum of residuals" Q4_3biii;
Q4_3biv=Q4_3biii/(nrow(YY)-2);                                             print "Mean square error" Q4_3biv;
Q4_3bv=sqrt(Q4_3biv)/(sqrt(Q4_3av));                                      print "standard error for B2" Q4_3bv;
Q4_3bvi=sqrt(Q4_3biv)*sqrt((Q4_3aiii/Q4_3ai*Q4_3av));                     print "standard error for B1" Q4_3bvi;
Q4_3bvii=Q4_3bi*Q4_3av;                                                    print Q4_3bvii;
Q4_3bviii=1-Q4_3biii/sum((yy-mean(yy))##2);                                print "Coeffient of determination" Q4_3bviii;
xxbar=mean(xx); print xxbar;
Q4_3bix=-(xxbar*Q4_3biv/Q4_3av);                                         print "Covariance of B1 and B2" Q4_3bix;
