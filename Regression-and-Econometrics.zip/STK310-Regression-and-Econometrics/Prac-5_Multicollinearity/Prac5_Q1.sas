proc import datafile="Consumption.csv"
out=Consumption
dbms=csv
replace;
run;

*Question 1a;
*Fitting the regression line to see if the multicollinearity or not;
proc reg data=Consumption plots=none;
model Y=X2 X3 X4/covb vif tol collin alpha=0.05;
run;

*Looking the overall F test and the Adjusted  R2:

  Ho:B2=B3=B4=0
  H1:Not all the slope coefficeints are simultaneoulsy zero
 
   Looking at the pvalue=0.0001 which is less than 0.01 we thus reject the null hypothesis at 1% level is significance

   Conclusion:There is enough statistical evidence to suggest that not all the slope 
        coeffiecinets are simultaneously zero
           meaning that is an overall good fit

 Adjusted R2:

 adjusted R2=0.8943, which means that 89.43% of variation in consumption expenditure is explined
  by the fitted model,which seems to suggust an overall good model fit
;



*Looking at the T-ratio: 

 Ho:Bj=0
 H1 not equal to zero for j=2,3,4

When looking at all these results it can be seen that even though we observed overall good model fit
none of the variables are seem to have a significant effect on consumption
by observing the t ratios and testing at 5% level of signifance.
Also by observing the standard errors of the parameter estimates, it can be seen that these error are 
relatively high to the pameter estimates which results in lower t-values;

;


*Looking at Correlation and partial correlation;
proc corr data=Consumption plots=matrix(histogram);
var Y X2 X3 X4;
run;


proc corr data=Consumption ;
var Y X2 ;
partial X3 X4;
run;
*the is very low correlation bethween Y and X2 while keeping X3 and X4 consant;

proc corr data=Consumption ;
var Y X3 ;
partial X2 X4;
run;
*the is relatively average correlation bethween Y and X2 while keeping X3 and X4 consant;

proc corr data=Consumption ;
var Y X4 ;
partial X2 X3;
run;
*the is a very low correlation between Y and X4 while keeping other variables constant;

*Looking at correlation between Y and X2 X3 X4 we can see that we have high correlation this might indicate
 multicollinearity but when looking at partial correlation coefficients between consumption expenditure and each of the
explanatory variables the correlations are much lower as insignificant this can be an indication of 
multicollinearity 

Looking at the pvalues in the original data we see that we might be reject the null
hypothesis while looking at pvalue in the patial correlation we see that we might not 
rejecting the null hypothesis;



*Looking at the VIF
 X2=12.29654 which is large than 10 which indicates high collinearity in the  model
 X3=9.23007 which is lower than 10 which indicates low collinearity
 X4=2.97664 which is less than 10 which may indicate low collinearity
 By looking at all the measures there is an indication of multicollinearit 
 in the data with relatively high VIF associated with X2 and X3;

*Looking at TOL
 X2=0.08132 which is a bit close to 0 indicating high collinearity
 X3=0.1084 not close to 0 thus low collinearity
 X4=0.33595 is  not close to 0 which indicate low collinearity
 By looking at all the measure there may indicate might collinearity 
 especiatially variable X2 since its TOL is closer to 0;

*Looking at Conditional Index
 X2=9.28490 Which indicates a moderate strong multicollinearity since it is between -10 and 30
 X3=13.98092 which indicates a moderate strong multicollinearity 
 X4=35.88644 which indicates sever multicollinearity since it is greater than 30
 Looking at the last CI value we can see that it is greater than 30 which indicates a severe
 multicollinearity;




*Question 1b;
*B3=0.75B2 B4=0.625B2
  Y=B1+B2Zi+u

thus new model: Y=B1+B2*X2+0.75*B2+0.025*B2+U
                Y=B1+B2(X2i+1.375)+U      this is after manipulation;

*Thus Zi=X2i+1.375;

*To fit this new model we need to create a new data;
data new;set Consumption;
Z=X2+0.75*X3+0.625*X4;
run;

*Then we need to fit our regreesion;
proc reg data=new plots=none;
model Y=Z;
run;

*then now we can get the estiamted B3 and B4 since they are unknown;
proc iml;
B2=0.70955;  *we get the new B2 estimated;
B3=0.75*B2;    print B3;
B4=0.625*B2;   print B4;
quit;


"
proc iml;
R2=0.9187;
VIF=1/(1-R2); print VIF;
TOL=1-R2;     print TOL;
quit;   
";




