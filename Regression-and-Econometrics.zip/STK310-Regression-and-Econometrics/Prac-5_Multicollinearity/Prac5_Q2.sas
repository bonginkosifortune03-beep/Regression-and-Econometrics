proc import datafile="Cars.csv"
out=Cars
dbms=csv
replace;
run;

*we then need to fit the regression function;
proc reg data=Cars plots=none;
model Y= X2 X3 X4 X5 X6/ collin vif tol;
run;


*Looking at Overall model fit(F-test and adjusted R2):
Ho:B2=B3=B4=B5=B6=0 
Hi:Not all the slope coefficieny are simultaneously zero

Thus looking at the pvalue=0.0074 which at 1% level is significant we do reject
 the null hypothesis

Conclusion: The is enough statistical evidence to suggest that not all the slope 
            coefficients are simultaneously zero,therefore it is a good model fit

Looking at the Adjusted R2=0.6318, Which means 63.18% of the variation in new
  car sales is explained by the fitted model, which seems to suggest an overall 
  good model fit;

*Looking the t ratio:
Ho:Bj=0 vs
H1 Bj not eqaul to 0 for j=2,3,4,5,6

 Looking at all these results it can be seen that even though we observed overall good
 model fit, none og the variables are seen to have a significant effect on car sales
 by observing the t ration and testing at 5% level of signifince
 Also by observing the standard errors of the parameter estimate it can be seen that
 these errors are high in relation to parameter estimates resulting in lower t values

 This is because looking at the pvalue for all of them we can see that they are greater than
 5% which means we do not reject thus we do not have eough statistival evidence
 to suggest that they are not equal to 0 all at once this means they are insignifincant(cause they equal zero)


*Looking at VIF:
all variables have VIF >10 means the is a severe multicollinearity besides
for X5

Looking at TOL:
All varaibles have TOL that is close to 0 indicating high collinearity besides
 X5

Looking at CL
X2 X3 indicate a moderate strong multicollinearity
X4 X5 X6 indicate a severe multicollinearity;

proc corr data=Cars;
var Y X2 X3 X4 X5 X6;
run;

*Looking at the correlation of Y and X2 X3 X4 X5 X6 we can see for majority 
 we have a low to negative linear relationship which  can show a low multicolinearity
 This could be that some of the ;

proc corr data=Cars;
var Y X2;
partial X3 X4 X5 X6;
run;
*Small weak relation between the variables;

proc corr data=Cars;
var Y X3;
partial X2 X4 X5 X6;
run;
*moderate negative relation between the variables;

proc corr data=Cars;
var Y X4;
partial X2 X3 X5 X6;
run;
*weak positive linear relation between the variables;


proc corr data=Cars;
var Y X5;
partial X2 X3 X4 X6;
run;
*weak negative relation between the variables;

proc corr data=Cars;
var Y X6;
partial X2 X3 X4 X5;
run;
*weak positive linear relation between the variables;

*Number 2ii;
*Not all the sing of the parameter estimates seem to make economic sense
 We expect to see a negative association between prices of cars and new car sales;

*Number 2b;
*we need to create a new variable;
data new; set Cars;
XX=X4/X3;
*Xnew=log(X4)-log(X3); *same thing;
run;

*Number 2c;
*we then need to do the transformation;
data newT; set new;
lnY=log(Y);
lnX2=log(X2);
*lnX4=Xnew;
lnX4=log(XX);
*lnX5=log(X5);
run;


*Fitting the linear regression;
proc reg data=newT plots=none;
model lnY= lnX2 lnX4  X5/collin vif tol;
run;

*Looking at the CL:
 we can see that the is moderate to sever multicollinearity related mostly wth lnX2
But looking at VIF:
 we just see that the is moderate not high multicollinearity
 The parameter estimates seem to make more sense in the context of the problem and the
 standard error seem to be lower and majority of individual paramter estimates are now
 significant as expected;

*Interpretion of beta:
 B2=-0.58613 means a 1% increase in  new Cars the expected sales of new cars will decrease by 0.59% keeping all other
   factors  constant
   
 *B4=1.75904 This means when real disposable income increase by 1%, the expected sales of new cars
    will increase by 1.76%, keeping all other factors constant

 *B5=-0.01811 This  means a 1 percentge increase in interest rates will cause 0.018% decrease in
  new cars sold ,keeping all other variables constant;

*C-ii,Yes they do make logical sense now that they have been transformed;

