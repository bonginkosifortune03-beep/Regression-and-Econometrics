proc import datafile="Copper.csv"
out=Copper
dbms=csv
replace;
run;
*we need to transform the data;
data new; set Copper;
LnC=log(C);
LnI=log(I);
LnL=log(L);
LnH=log(H);
LnA=log(A);
run;

*Question 1b;
proc reg data=New plots=none;
model LnC=LnI LnL LnH LnA/r;
run;
*then lnC_hat=-1.50044+0.46751*lnI+0.27944*lnL-0.00515*LnH+0.44145*LnA;

*Question 1c;
*getting the residuals;
proc reg data=New plot=none;
model LnC=LnI LnL LnH LnA;
output out=Residuals
r=res;
run;

*Scatter plot residuals over time;
proc sgplot data=Residuals;
scatter x=Year y=res;
run;

*we also need to create the lag;
data new1;set Residuals;
reslag=lag(res); *this is one lag;
run;
*scatter plot of residual and lagged residuals;
proc sgplot data=new1;
scatter x=reslag y=res;
run;

*Question 1d;
*using the Durbin-Watson;

*Ho:No positive or negstive first order autocorrelation present
 H1:positve or negative aautocorrelation present;

**Durbin-Watson d-statistic*;
proc reg data=new1 plots=none;
model LnC=LnI LnL LnH LnA/dw;
run;

*Our DW D statistic= 0.955
Our n=30
Our k-prime=4
 then Dl=1.143 and Du=1.739
so looking the Dstat we see that it is between 0 and Dl then we will
use 0< DW < Dl interval

Decision:   We reject the null hypothesis of no positve correlation at 5% level
            of significance
Conclusion: Meaning we have statistical evidence to suggest that the is positive 
            auto correlation present in the residual terms;


*Question 1e;

*we then need to get the Runs for the model;
data new2;set Residuals;
if res<0 then sign=1;       *negative runs;
if res>0 then sign=2;       *positive runs;
run;
*then to get the number residual error runs we need to the frequency proc;
proc freq data=new2;
table sign;
run;
*We need to get the confidence interval;
proc iml;
N1=17;
N2=13;
N=30;
R=9;
meanR=(2*(N1*N2)/N)+1;                       print 'mean of r' meanR;
varR=(2*N1*N2*((2*N1*N2)-N))/((N**2)*(N-1)); print 'variance of R' varR;
Crit=quantile('normal',1-(0.05/2),0,1);      print 'critical value' Crit;
margin=Crit*sqrt(varR);       
Lower=meanR-margin;                          print 'Lower bound' Lower;
Upper=meanR+margin;                          print 'Upper bound' Upper;
*Confidence interval=(10.556221,20.910446)

Decision: We reject the null hypothesis since 9 is not the
          element of the confidence interval
Conclusion: Meaning there is enough statistical evidence to suggest that autocorrelation
          is present in the residual terms;
quit;

*Question 1f;
*So the Durbin-Watson first-order coefficient of autocovariance is

p_hat=0.520;
data new3; set new2;
LnC_L=lag(LnC);
LnI_L=lag(LnI);
LnL_L=lag(LnL);
LnH_L=lag(LnH);
LnA_L=lag(LnA);

*multiply by P and substract the lag;
LnC_Lt=LnC-0.520*LnC_L;
LnI_Lt=LnI-0.520*LnI_L;
LnL_Lt=LnL-0.520*LnL_L;
LnH_Lt=LnH-0.520*LnH_L;
LnA_Lt=LnA-0.520*LnA_L;
run;
*then we need to do DW test of this new data;
proc reg data=new3 plots=none;
model LnC_Lt=LnI_Lt LnL_Lt LnH_Lt LnA_Lt/dw
run;
*so we see that the new regressiob equation is
 LnC*t=-0.60487 + 0.39924*LnI*+ 0.33840*LnL* - 0.05060*LnH* + 0.45355*LnA*;

*using the Durbin-Watson table

Ho: No positive or negative first-order autocorrelation present
H1: Positive or negative first-order autocorrelation present

 K=4
 N=29
 Dstat=1.443
 DL=1.124
 DU=1.743
*with this one we see that the Dstat is between DL < dstat < DU

Decision: Meaning the is no decison to be made regarding the presence positive autocorrelation
Conclusion: No informed conclusion can be made regarding the presence of positive auntocorrelation;


*Question 1g;
*using the Cochrane-Orcutt 
we need to get the lag of the residuals;

*step1;
proc reg data=new plots=none;
model LnC=LnI LnL LnH LnA/r;
output out=Residual_1
r=Res_1;
run;

*step2;
data new4; set Residual_1;
res_lag_1=lag(Res_1);
run;

*step3;
*to get the P;
proc reg data=new4 plots=none;
model Res_1=res_lag_1/noint;
run;

*step4;
*P_hat=0.52084;
data new5; set new4;
LnC_L_1=lag(LnC);
LnI_L_1=lag(LnI);
LnL_L_1=lag(LnL);
LnH_L_1=lag(LnH);
LnA_L_1=lag(LnA);

*multiply by P and substract the lag;
LnC_Lt_1=LnC-0.52084*LnC_L_1;
LnI_Lt_1=LnI-0.52084*LnI_L_1;
LnL_Lt_1=LnL-0.52084*LnL_L_1;
LnH_Lt_1=LnH-0.52084*LnH_L_1;
LnA_Lt_1=LnA-0.52084*LnA_L_1;
run;

*step5;
*then we need to do DW test of this new data;
proc reg data=new5 plots=none;
model LnC_Lt_1=LnI_Lt_1 LnL_Lt_1 LnH_Lt_1 LnA_Lt_1/dw
run;

**so we see that the new regressiob equation is
 LnC*t=-0.60367 + 0.39904*LnI*+ 0.33840*LnL* -0.05064*LnH* + 0.45362*LnA*;

*using the Durbin-Watson table
*H0 : No first-order autocorrelation (+- ) vs 
 H1 : First-order autocorrelation ( +-)
 K=4
 N=29
 Dstat=1.444
 DL=1.124
 DU=1.743
*We see that Dstat is between DL< Dstat < DU

Decision: No decision can be made regarding the presence of positive autocorrlation
Conclusion: No informed conclusion can be made regarding the presence of positive
            autocorrelation
