proc import datafile="Copper.csv"
out=Copper
dbms=csv
replace;
run;
*we need to transform the data;
data new; set Copper;
LnC=log(C);
LnI=log(I);
LnL=log(L);
LnH=log(H);
LnA=log(A);
run;


*Question 1g;
*using the Cochrane-Orcutt 
we need to get the lag of the residuals;

*step1;
proc reg data=new plots=none;
model LnC=LnI LnL LnH LnA/r;
output out=Residual_1
r=Res_1;
run;

*step2;
data new4; set Residual_1;
res_lag_1=lag(Res_1);
run;

*step3;
*to get the P;
proc reg data=new4 plots=none;
model Res_1=res_lag_1/noint;
run;

*step4;
*P_hat=0.52084;
data new5; set new4;
LnC_L_1=lag(LnC);
LnI_L_1=lag(LnI);
LnL_L_1=lag(LnL);
LnH_L_1=lag(LnH);
LnA_L_1=lag(LnA);

*multiply by P and substract the lag;
LnC_Lt_1=LnC-0.52084*LnC_L_1;
LnI_Lt_1=LnI-0.52084*LnI_L_1;
LnL_Lt_1=LnL-0.52084*LnL_L_1;
LnH_Lt_1=LnH-0.52084*LnH_L_1;
LnA_Lt_1=LnA-0.52084*LnA_L_1;
run;

*step5;
*then we need to do DW test of this new data;
proc reg data=new5 plots=none;
model LnC_Lt_1=LnI_Lt_1 LnL_Lt_1 LnH_Lt_1 LnA_Lt_1/dw
run;

**so we see that the new regressiob equation is
 LnC*t=-0.60367 + 0.39904*LnI*+ 0.33840*LnL* -0.05064*LnH* + 0.45362*LnA*;

*using the Durbin-Watson table
*H0 : No first-order autocorrelation (+- ) vs 
 H1 : First-order autocorrelation ( +-)
 K=4
 N=29
 Dstat=1.444
 DL=1.124
 DU=1.743
*We see that Dstat is between DL< Dstat < DU

Decision: No decision can be made regarding the presence of positive autocorrlation
Conclusion: No informed conclusion can be made regarding the presence of positive
            autocorrelation
