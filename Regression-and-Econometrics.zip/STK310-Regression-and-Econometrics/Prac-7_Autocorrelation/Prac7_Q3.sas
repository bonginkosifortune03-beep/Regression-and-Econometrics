proc iml;
n=100;
r=100;
rho=0.1;
dim=n||r;

*generating values;
call randseed(439,1); Xt=randfun(dim,"normal",5,3);
call randseed(984,1); eps=randfun(dim,"normal",0,1);

**creating error values;
u=J(n,r,10);
do i=2 to n;
u[i,]=rho*u[i-1,]+eps[i,];
end;
*print u;

*then now create y values;
**Y=3+0.5X+u**;
dy=J(n,1,1)*3+0.5*Xt+u;

*creating transformed variables as in difference equation;
tdx=J(n-1,r,.);
tdy=J(n-1,r,.);

do s=1 to n-1;
tdx[s,]=Xt[s+1,]-rho*Xt[s,];

tdy[s,]=dy[s+1,]-rho*dy[s,];
end;
*print tdy;

*what is this for;
do t=1 to r;
x=J(n,1,1)||Xt[,t];  *design matrix;
y=dy[,t];

tx=J(n-1,1,1)||tdx[,t]; *desigm matrix;
ty=tdy[,t];

*getting the betas for OLS anf GLS;
betaOLS=inv(x`*x)*x`*y;
betaGLS=inv(tx`*tx)*tx`*ty;
beta_all_OLS=beta_all_OLS||betaOLS;
beta_all_GLS=beta_all_GLS||betaGLS;
end;
print beta_all_OLS beta_all_GLS;

*getting the means and variance of OLS;
meansOLS=mean(beta_all_OLS`)`;
varOLS=var(beta_all_OLS`)`;
print meansOLS varOLS;

*getting the means and variance of OLS;
meansGLS=mean(beta_all_GLS`)`;
varGLS=var(beta_all_GLS`)`;
print meansGLS varGLS;


