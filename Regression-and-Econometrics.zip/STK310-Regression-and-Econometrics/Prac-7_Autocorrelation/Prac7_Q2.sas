proc iml;
*Question 2a;
n=20;
k=3;
dstat=1.85;
DL=0.998;
DU=1.676;
*playing around;
F=4-DU; print F;

*We then see that DU< dstat < 4-DU
                  1.676 < dstat < 2.324
Decision:  Do not reject null hypothesis of no positive or negative autocorrelatio
           at 5% level of significance
Coclusion: We do not have enough statistical evidence to suggest that the
          presences of positive or negative autocorrelation;


*Question 2b;
n=25;
k=10;
dstat=3.75;
DL=0.544;
DU=2.560;

*playing around;
/*C=4-DU; print C;*/
D=4-DL; PRINT D;

*we see that 4-DL < Dstat < 4
             3.456 < 3.75 < 4

Decision:   We thus reject the null hypothesis of no negative autocorrelation
Conclusion: We thus have enough statistical evidence to suggest that the is a presence
            of negative autocorrelation; 



*Question 2c;
n=25;
k=10;
dstat=3.55;
DL=0.544;
DU=2.560;

*playing around;
D=4-DL; PRINT D;
C=4-DU; print C;

*We that 4-DU < Dstat < 4-DL
         1.44 < Dstat < 3.456

Decision: No decision can be made regarding the presence of nagative autocorrelation
Conclusion: No decision can be made about the presence of negative autocorrelation;
quit;
