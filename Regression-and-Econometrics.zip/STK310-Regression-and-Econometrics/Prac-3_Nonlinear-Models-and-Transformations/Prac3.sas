proc import datafile="mouse.csv"
out=mouse
dbms=csv
replace;
run;

*Question 1a";
proc sgplot data=mouse;
title 'Mass in gram over time';
xaxis label='Mass';
yaxis label='Time';
scatter x=t y=y;
run;

*Question 1b;
*we need to transform using thr log linear model;
data new;set mouse;
lnY=log(Y);
ln_t=t;
run;

*scatter plot;
proc sgplot data=new;
title 'Mass in gram over time';
xaxis label='Mass';
yaxis label='Time';
scatter x=ln_t y=lnY;
run;

*Question 1c;
proc reg data=new;
model lnY=ln_t/ p r covb;
run;
"
ln_yhat=2.54590+0.16038*t

i-B2=0.16038 the instataneous rate of growth=16.04%

ii-r::Compound rate=0.1739569
      thus te compound rate of growth is 17.4

iii  lnYo=2.54590 this is were t=0 at an intercept
     Therefore the original Yhat0=12.754702
 "
;
proc iml;
b2=0.16038;
r=exp(0.16038)-1;      print 'Compound rate' r;
y0=exp(2.54590);       print 'The mass of the mouse at birth' y0;
quit;

*Question 1d;
proc reg data=new;
model lnY=ln_t/ p r covb clm cli alpha=0.05;
id ln_t;
run;
"The 95% Confidence Interval=(3.2131,3.4825) for the transformed dataset
 Thus the correct absolute mean interval is (24.856021,32.540973) calculated below";
proc iml;
ab_lower=exp(3.2131);  print ab_lower;
ab_upper=exp(3.4825);  print ab_upper;
quit;


*Question 1e;
proc reg data=new;
model lnY=ln_t/ p r covb clm cli alpha=0.1;
id ln_t;
run;

proc univariate data=new;
var lnY ln_t;
run;
 
proc iml;
mean=5; *from proc univariate;
x0=10;  *Ten weeks t as X;
CSS=60; *from proc univariate;
N=9;    *either proc reg or univariate;
b1=2.54590;
b2=0.16038;
sigma2=0.02920; *from proc reg;
sigma=sqrt(sigma2);
y0hat=b1+(b2*x0);                                print y0hat;
*psq=sigma2*sqrt(1+(1/9)+((x0-mean)**2)/CSS);    print psq;
margin_err=(quantile('t',1-(0.1/2),(N-2)))*sigma*sqrt(1+(1/9)+((x0-mean)**2)/CSS); print margin_err;
lower_b=y0hat-margin_err;                       print 'Lower bound' lower_b;
upper_b=y0hat+margin_err;                       print 'Upper bound' upper_b;

*we then need to get the absolute y values by taking the e of ln;
ab_lower_b=exp(lower_b);                      print 'Correct abs lower bound' ab_lower_b;
ab_upper_b=exp(upper_b);                      print 'Correct abs lower bound' ab_upper_b;
quit;



*Question 1f;
*creating a new dataset that has absolute values of y;
data ab_new; set new;
ab_Y=exp(lnY);
run;

proc iml;
use ab_new;
read all var{ t Y ln_t lnY ab_Y} into M;
print M;
t=J(nrow(M),1,1)||m[,1];   *getting the design  x values;
y=m[,2];                   *getting the actual y vlaues;
t1=J(nrow(M),1,1)||m[,3];  *getting the design expanatory values of x;
y1=m[,4];                  *gettinh the transformed y;

b=inv(t`*t)*t`*y;         print 'Actual betas' b;
b_t=inv(t`*t)*t`*y1;      print 'Transformed betas' b_t;
quit;

*Question 2;
proc import datafile="motorcycles.csv"
out=motorcycles
dbms=csv
replace;
run;

*Question 2a;
proc sgplot data=motorcycles;
title 'Sound intensity level against the distance';
xaxis label='Distance(in meters)';
yaxis label='Sound intesity level(in decibels)';
scatter x=X y=Y;
refline 61.73009 / axis=y lineattrs=(thickness=3 color=darkred pattern=dash);
run;

*Question 2b;
*The reciprocal model we just change X values;
data new_motorcycles; set motorcycles;
z=1/x;
run;


proc reg data=new_motorcycles plots=none;
model y=z/ p r cob;
id z;
run;
"The regression line is:
y=61.73009+71.49212*z or it can be written as y=61.73009+71.49212*(1/x)

The asympototic sound intensity is 61.73009 decibels";

*Question 2c;
proc iml;
z=-71.49212*(1/(4*82)); print "percentage change in sound intensity " z;
"y=61.73009+71.49212*z
Interpretation: The expected intesity level will decrease by 0.22% for a 1%
               increase in distance,when measured at a distance of 4 meter and sound 
			   intensity level reading is 82 decilesb";
quit;

*Question 2d;
proc iml;
use new_motorcycles;
read all var{X Y z} into ZZ;
print ZZ; 

x=J(nrow(ZZ),1,1)||ZZ[,1]; print x;*getting the desing matric;
y=ZZ[,2];                   *getting the actual y values;
x1=J(nrow(ZZ),1,1)||ZZ[,3];                  *getting transformed x values;

*i=inv(x`*x)*x`*y;         *  print 'Actual Beta values' i;
i=inv(x1`*x1)*x1`*y;      print 'Transformed Beta values' i;

"
uu=(y-x1*i_i)`*(y-x1*i_i);  print 'for the transformed ' uu;
k=2;                        *the parameter we are estimating;
ii=uu/(nrow(ZZ)-k);         print 'Estimated value of variance-(sigma2)' ii;
iii=ii*inv(x1`*x1);         print 'Covariance matrix' iii";
yhat=x1*i; 
u=y-yhat;   
ii=(u`*u)/(nrow(ZZ)-2);   print 'the variance' ii;
covb=ii*inv(x1`*x1);      print 'The covariance' covb;

quit;

*Question 3;
proc import datafile="cereal.csv"
out=cereal
dbms=csv
replace;
run;

*Question 3ai;
proc corr data=cereal plots=matrix(histogram);
var Y X2 X3 X4;
run;


*Question 3aii;
*First order correlation is just the ordinary correltion;
proc corr data=cereal;
var Y X2 X3 X4;
run;

*Question 3aiii;
proc reg data=cereal;
model Y=X2 X3 X4/ p r pcorr2 selection=adjrsq;
id  X2 X3 X4;
run;
"The best adjusted R2 is where the combination of explanatory variable for Y is X2 AND X3";

*Question 3bi;
proc corr data=cereal;
var Y X2;
partial  X3;
run;
*
Correlation:-0.88053
Interpretation: The is a strong negative linear association between demand of Cereal A and price of Cereal A while 
keeping X3 constant

*This means that if price of Cereal A  increase the demand for Cereal A decrease, keeping the price of Cereal B
constant;
 

*Question 3bii;
proc corr data=cereal;
var Y X3;
partial X2;
run;
*
Correlation:0.64568
Interpretation:The is a weak positive linear relationship between demand of Cereal A and price of Cereal B;


*Question 3c;
*For this question we need to do a double log transformation;
data newCereal; set cereal;
lnY=log(Y);
lnX2=log(X2);
lnX3=log(X3);
run;

*Question 3ci;
proc reg data=newCereal;
model lnY=lnX2 lnX3;
run; *for checking whether the values I got on the new codes are correct;
*yhat=5.55680-1.76360*X2+1.35247X3
B2=-1.76360::The expected demand for Cereal A will decrease by 1.76%
 for a  1% increase in the price of Cereal A by keeping the price

B3= 1.35247:This means that the expected demand for Cereal A will increase 
    1.35% for a 1% increase in the price of Cereal B keeping the price of 
    Cereal A constant;


*Questiobn 3cii;
proc iml;
lnB1=5.5568;     *for the transformed alpha;
alphaB1=exp(lnB1);  print 'Actual alpha' alphaB1;
quit;

*Question 3ciii;
proc means data=cereal;
var Y X2;
run;
*using the average to get the slope;
proc iml;
B2=-1.76360;
mean_Y=76.5000000;
mean_X2=31.0437500;
slope=(B2)*(mean_Y/mean_X2); print slope;
quit;


*Question 3iv;
proc reg data=newCereal plot=none;
model lnY=lnX2 lnX3/p r;
output out=pred
p=pred
r=res;
run;

proc univariate data=pred normal;
var res;
run;
" H0:Distribution does not differ from a normal distribution
  H1:Distribution does differ from a normal distribution

At a 5% level of significance
p_value=09747 which is greater than the level of signifiance thus do not reject the null hypothesis

Conclusion:The is no enough statistical evidence to suggest that residual distribution
differs from the normal distributino";

*Qeustion 3v;
proc reg data=newCereal plots=none;
model lnY=lnX2 lnX3/ p r covb clb alpha=0.1;
id X2 X3;
run; 
*A:: Ho:betas=0
     H1:betas /=0

B:: 
For lnX2 confidence interval:(-2.64703,-0.88017) 
we thus  reject the null hypothesi since 0 is not the element 
of the confidence interval

Conclusion:We have enough evidence to suggest that B2 is not equal to 0,therefore there a signficant
relationship between Y X2

For lnX3 confidence interval:(0.20306,2.90800) we thus do not reject the null
hypothesis since zero is an element of the confidence interval

Conclusion: We thus don't have enongh statistical evidence to suggect that B3 is not equal 
to zero,thus there is signficant relationship between Y X3;


*Question 3vi;
"Using the above proc reg

Ho: B2=B3 or B2-B3=0;
 H1: B2=/B3 or B2-B3=/0; OR H1:Not all betas are simultaneously equal to zero

alpha=0.01

pvalue=0.0002 which is less than alpha thus we reject the null hypothesis at 1% level
significance;

Conclusion: There is enough statistical evidence to suggest that not all betas
are simultaneously equal to zero,therefor the overval model fit is good;
";

*Question 3cvii;
*Testing if the two partial regression coefficients are eqaul;
proc reg data=newCereal;
model lnY=lnX2 lnX3/ p r covb clb alpha=0.5;
test1: test lnX2-lnX3=0;
id X2 X3;
run; 
"
A:
Ho:B2=B3  or Ho:B2-B3=0;
H1:B2=/B3 or Ho:B2-B3=/0

B:
 t-test
";
proc iml;
B1=-1.76360;
B2=1.35247;
varB1=0.0860117063;
varB2=0.2666651662;
covBetas=-0.07350782;
se_Betas=sqrt(varB1+varB2-2*(covBetas));          print se_Betas;
ttest=((B1-B2)-0)/(se_Betas);                                    print 'Manual t test' ttest;
t_Crit=quantile('t',1-(0.05/2),(16-3));           print 'T critical value' t_Crit;
f_Crit=quantile('f',(1-0.05),1,13);             print f_Crit;
quit;
"
Decision:Reject the null hypothesis at a 5% level of significance,since -4.408<-2.1603687;
Conclusion:There is enough statistics evidence to suggest that the two partial regression coefficients
            differ from each other
   
Using F test:
  F-test=19.43 which is greater than F_critical=4.6671927 we thus reject
  the null hypothesis

  Conclusion:There is enough statistical evidence to suggest that the two
  partial regression coefficients differ from each other

";

*Question 3c_viii;
proc reg data=newCereal;
model lnY=lnX2 lnX3/ p r covb clb alpha=0.01;
test2: test lnX2+lnX3=-0.5;
id X2 X3;
run; 
"
Ho:B2+B3=-0.5
Hi:B2+B3/=-0.5

Fstat=0.04 with F critical value=9.0738057 thus we do not reject the null hypothesis

Conclusion:There is no enough statistics evidencr to suggest that B2+B3=/0.5;

Tstat=0.2 (it positive) and our critical value=3.0122758 we thus do not reject null hypothesis since test
      statistic is less than critical value;

Conclusion:There is no enough statistical evidence to suggeust that B2+B3/=-0.5;

";
proc iml;
ff_crit=quantile('f',(1-0.01),1,13); print 'F critical value' ff_crit;
t_test=sqrt(0.04);    print 'T test statistic' t_test;
se_B1_B2=sqrt(0.0860117063+0.2666651662+2*(-0.07350782)); print se_B1_B2;
M_t_test=((-1.76360+1.35247)-(-0.5))/se_B1_B2; print M_t_test;
tt_crit=quantile('t',1-(0.01/2),(16-3)); print  'T Critival' tt_crit;
quit;

*Question 3c_ix;
proc reg data=newCereal plot=none;
model lnY=lnX2 lnX3/  p r clb alpha=0.01;
run;

"We thus reject the null hypothesis at 1% level of signifinance since -3 is not an element of (-2.64703; -0.88017 )
Conclusion:There is enough statistical evidence to suggest that  B2/=-3,therefore the percentage decrease in the 
expected demand for Cereal A differs from 3% for 1% increase in the price of Cereal A";

*Question 3c_x;
proc reg data=newCereal plot=none;
model lnY=lnX2 lnX3/  p r clb clm  alpha=0.01;
id X2 X3 lnX2 lnX3;
run;
"The confidenc interval for mean prediction interval is for the transformed data( 3.9053 4.2617)
The confidenc interval for mean prediction interval is for the actual data( 49.6650,70.9305)";
proc iml
l=exp(3.9053); print l;
u=exp(4.2617); print u;
quit;
 
*Question 3d;

*Question 3d_i;
proc iml;
use newCereal; read all var{lnX2 lnX3 lnY} into M;
*print M;
x=J(NROW(M),1,1)||M[,1]||M[,2];
y=M[,3]; 
*Question 3d_ii;
betas=inv(x`*x)*x`*y; print 'Beta Coefficient values' betas;
"Yhat=5.5567987-1.763601x2+1.3524687x3";

*Question 3d_iii;
N=nrow(M);        print 'Number of observation' N;
yhat=x*betas;     print 'Predicted Y value' yhat;
u=y-yhat;         print 'Residuals' u;
ybar=mean(Y);     print 'Mean of Y' ybar;
ESS=betas`*x`*y-n*ybar**2;  print 'Explained Sum of Sqaure' ESS;
TSS= y`*y-n*ybar**2;        print 'Total sum of squeares' TSS;
R2=ESS/TSS;                 print 'Coeffient of determination' R2;
AdjR2=1-(1-R2)*(N-1)/(N-3); *Adjusted R2;

*Question 3d_iv;
"Ho:Bj=0 vs H1:Bj/= 0";
sigma2=u`*u/(n-3); *the variance;
covb=sigma2*inv(x`*x); *the covariance;
t2=(betas[2]-0)/sqrt(covb[2,2]); print 't test statistic' t2;
t_pvalue2=2*(cdf('t',t2,(n-3))); print 'P value for T' t_pvalue2;
"We thus reject the null hypothesis
We have enough statistical evidence to suggest the b2 b3 differs from zero";

t3=(betas[3]-0)/sqrt(covb[3,3]); print 't test statistic' t3;
t_pvalue3=2*(1-cdf('t',t3,(n-3))); print 'P value for T' t_pvalue3;
"We thus reject the null hypothesis
We have enough statistical evidence to suggest the b2 b3 differs from zero";


*Question 3d_iv;
RSS=u`*u;
Fstat=(ESS/2)/(RSS/(N-3)); Print 'F statistic' Fstat;
Fcrit=quantile('F',0.95,2,13); print 'Critical value' Fcrit;
pvalue=1-cdf('f',Fstat,2,13); print 'P value' pvalue;
"Decision:Reject the null hypothesis since Fstat is greater than Fcrit value
Conclusion: The is enough statistical evidence to suggest that the overvall model fit is good"; 


